(variable) @variable
(string) @string
