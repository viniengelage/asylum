; ============================================================
; TwoL (Two-Level Morphology) — Zed highlights query
; ============================================================

; Section keywords
[
  (alphabet_keyword)
  (diacritics_keyword)
  (sets_keyword)
  (definitions_keyword)
  (rules_keyword)
] @keyword

; Rule operators  =>  <=  <=>  /<=  /=>
(rule_operator) @operator

; Rule names  "N:m before input-character p"
(rule_name) @string

; Comments  ! ...  and  !! ...
(comment) @comment

; Pairs  a:b  N:m  k:0  0:i
(pair
  input: (_) @constant
  ":" @punctuation.delimiter
  output: (_) @constant)

; Wildcards  :a  a:  ?  ?:?
(left_wildcard
  ":" @punctuation.delimiter
  output: (_) @constant)

(right_wildcard
  input: (_) @constant
  ":" @punctuation.delimiter)

(any_pair) @constant.builtin

; Epsilon / null symbol  0
(zero) @constant.builtin

; Word boundary  .#.
(boundary) @constant.builtin

; Set / definition names (LHS of = in Sets and Definitions)
(set_definition
  name: (identifier) @type)

(named_definition
  name: (identifier) @type)

; References to sets and definitions inside expressions
(primary_expr
  (identifier) @type)

; Regex operators
[
  "*" "+" "?"
  "|" "&" "-"
  "~" "\\" "$" "$."
] @operator

; Grouping brackets  [ ]  ( )
[
  "[" "]"
  "(" ")"
] @punctuation.bracket

; Statement terminator  ;
";" @punctuation.delimiter

; Context separator  _
"_" @punctuation.special

; Bare symbols (plain characters in alphabet / sets / rules)
(bare_symbol) @string.special.symbol

; %-quoted symbols  %0  %.  %#  etc.
(quoted_symbol) @string.escape
