; Zed's outline panel and breadcrumbs nest items by their ranges: a
; section spans everything up to the next heading of its level or
; higher, a scene everything up to the next scene or section heading,
; and a dialogue block its cue and speech. The #'s of a section are its
; context; a scene's #number# is left out of its name.

(section
  (section_heading
    (section_marker) @context
    (section_title)? @name)) @item

(scene
  (scene_heading
    (scene_title) @name)) @item

(dialogue_block
  (character
    (character_name) @name)) @item
