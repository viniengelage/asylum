; Vim mode: a scene is a "function" (af/if), a section a "class" (ac/ic).

(scene
  (scene_heading)
  (_)* @function.inside) @function.around

(section
  (section_heading)
  (_)* @class.inside) @class.around

(note) @comment.around
(boneyard) @comment.around
