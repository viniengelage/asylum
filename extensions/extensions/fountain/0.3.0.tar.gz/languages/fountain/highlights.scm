; Fountain highlights for Zed. Every node name here must exist in the
; grammar (src/node-types.json of tree-sitter-fountain): Zed drops the
; whole file when one does not.

; Title page
(title_key) @property
(title_value) @string.special

; Structure
(section_marker) @punctuation.special
(section_title) @title
(synopsis) @comment.doc
(scene_heading) @keyword
(scene_number) @number
(page_break) @punctuation.special

; Dialogue
(character) @type
(character_extension) @attribute
(dual_dialogue_marker) @operator
(parenthetical) @comment
(dialogue) @string
(lyric) @string.special

; Other elements
(transition) @label
(centered) @text.literal

; Forcing characters (. @ ! ~ > =) and the closing < of centered text
(force_marker) @punctuation.special
(centered_end) @punctuation.special

; Inline
(italic) @emphasis
(bold) @emphasis.strong
(bold_italic) @emphasis.strong
(underline) @link_text
(escape) @string.escape

; Left out of the script: last, so they win over the element around them
(note) @comment
(boneyard) @comment
