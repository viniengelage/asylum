("<" @open
  "/>" @close)

("</" @open
  ">" @close)

("<" @open
  ">" @close)

("\"" @open
  "\"" @close)

((element_node
  (open_tag) @open
  (close_tag) @close)
  (#set! newline.only))
