(comment) @comment

(header) @keyword

(section) @constant
(section_path) @string.special

"[" @punctuation.bracket
"]" @punctuation.bracket

(entry) @none

(value_name) @string.special
"=" @operator

(value_data) @none

(value_type) @keyword.type
":" @punctuation.delimiter

(string) @string
(escaped_char) @string.escape

(number) @number

(hex_list) @none
(hex_byte) @number

"," @punctuation.delimiter

"@" @constant.builtin
