[
  (union_statement)
  (difference_statement)
  (block_statement)
] @indent

[
  ")"
  "}"
] @end
