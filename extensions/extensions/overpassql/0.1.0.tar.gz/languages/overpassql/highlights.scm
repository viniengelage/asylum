; Query types (node, way, relation, nwr, area, ...)
(query_type) @keyword

; Block / control statements
(block_keyword) @keyword

; Output statement
"out" @keyword
(output_modifier) @keyword.modifier

; Recursion operators
(recurse_statement) @operator

; Settings: [out:json] -> name is a directive
(setting
  name: (identifier) @attribute)

; Spatial filter leading keywords
[
  "around"
  "area"
  "pivot"
  "poly"
  "id"
  "newer"
  "user"
  "uid"
] @function.builtin

; Tag-filter keys and values
(tag_filter
  key: (identifier) @property)
(tag_filter
  key: (string) @property)
(tag_filter
  value: (identifier) @string)
(tag_filter
  value: (string) @string)

; Set names: .result and ->.result
(input_set (identifier) @variable.special)
(standalone_input_set (identifier) @variable.special)
(assign_set (identifier) @variable.special)

; Literals
(number) @number
(string) @string
(escape_sequence) @string.escape
(comment) @comment

; Operators
(comparison_operator) @operator
"->" @operator
"-" @operator
"!" @operator
"~" @operator

; Punctuation
[ ";" "," ":" "." ] @punctuation.delimiter
[ "(" ")" "[" "]" "{" "}" ] @punctuation.bracket
