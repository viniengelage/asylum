; Square brackets for direct relationships and arrays
("[" @open "]" @close)

; Curly braces for condition bodies and blocks
("{" @open "}" @close)

; Parentheses for function calls, arguments, and condition parameters
("(" @open ")" @close)
