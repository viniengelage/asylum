; Keywords
[
  "model"
  "schema"
  "type"
  "relations"
  "define"
  "from"
  "extend"
  "module"
  "condition"
  "with"
] @keyword

; FGA specific operators
[
  "or"
  "and"
  "but not"
] @operator

; Version numbers
(version) @number

; Comments
(comment) @comment

; Type declarations
(type_declaration
  (identifier) @type)

; Relation definitions
(definition
  relation: (identifier) @property)

; Condition declarations
(condition_declaration
  name: (identifier) @function)

; Function parameters
(param
  (identifier) @variable.parameter)

; Built-in types
((type_identifier) @type.builtin
  (#match? @type.builtin "^(string|int|map|uint|list|timestamp|bool|duration|double|ipaddress)$"))

; Punctuation
[
  "["
  "]"
  "{"
  "}"
  "("
  ")"
] @punctuation.bracket

[
  ","
  ":"
] @punctuation.delimiter

; Generic identifiers
(identifier) @variable
