("[" @open "]" @close)
("{" @open "}" @close)