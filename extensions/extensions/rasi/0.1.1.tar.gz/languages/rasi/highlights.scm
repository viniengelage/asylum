; adapted from https://github.com/Fymyte/tree-sitter-rasi/blob/main/queries/highlights.scm

(comment) @comment

"@media" @keyword
"@import" @keyword
"@theme" @keyword

(string_value) @string
(boolean_value) @boolean
[
  (integer_value)
  (float_value)
  "0"
] @number

[
  (feature_name)
  (url_image_scale)
  (direction)
  (text_style_value)
  (line_style_value)
  (position_value)
  (orientation_value)
  (cursor_value)
  "inherit"
  "DMENU"
] @keyword

(url_image "url" @function.builtin)
(gradient_image "linear-gradient" @function.builtin)
(distance_calc "calc" @function.builtin)
(rgb_color ["rgb" "rgba"] @function.builtin)
(hsl_color ["hsl" "hsla"] @function.builtin)
(hwb_color ["hwb" "hwba"] @function.builtin)
(cmyk_color "cmyk" @function.builtin)

(distance_op) @operator

[
 "("
 ")"
 "{"
 "}"
 "["
 "]"
] @punctuation.bracket

[
 ";"
 ","
 ":"
 "."
] @punctuation.delimiter

(percentage) @number
(percentage "%" @type)
[
 (angle_unit)
 (integer_distance_unit)
 (float_distance_unit)
] @type

[
  (global_selector)
  (id_selector)
] @variable.special

(id_selector_view [ "normal" "selected" "alternate" ] @property)
(id_selector_state [ "normal" "urgent" "active" ] @tag)

(hex_color) @number
(hex_color "#" @punctuation.special)
(named_color (identifier) @string.special)
(named_color "/" @operator)
(reference_value "@" @punctuation.special (identifier) @variable)
(reference_value "var" @function.builtin (identifier) @variable)
(list_value (identifier) @variable)
(environ_value "$" @punctuation.special (identifier) @variable)
(environ_value "env" @function.builtin (identifier) @variable)

(id_selector "#" @punctuation.special)
(property_name) @property

(ERROR) @hint ; might be incorrect
