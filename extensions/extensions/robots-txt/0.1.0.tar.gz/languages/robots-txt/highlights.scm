(comment) @comment

(directive) @keyword

(unknownDirective) @attribute

(value) @string

":" @punctuation.delimiter
