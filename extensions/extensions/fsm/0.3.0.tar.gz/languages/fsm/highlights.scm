(action_pointer_expression_type) @type
(symbol_expression_type) @type
(string_expression_type) @type
(symbol_expression_type) @type
(or_expression_type) @type
(reflect_expression_type) @type

(symbol_expression) @string.special.symbol
(or_expression) @operator
(prop_expression) @property
(prop_pointer_expression) @constant
(action_pointer_expression) @constant
(reflect_expression) @punctuation.bracket


(actions_statement) @keyword
(prop_statement) @keyword
(optional_prop_statement) @keyword @variant
(action_statement 
  expression: (expression) @variable.special
) @function
(on_statement) @keyword
(move_statement) @keyword
(or_assign_statement) @operator @keyword
(block_statement) @punctuation.bracket
(await_statement 
  action: (expression) @variable
  resolved: (statement) @function
  rejected: (statement) @emphasis @function
) @keyword
(route_statement
  name: (expression) @string.special.symbol
  procedure: (statement) @function
) @keyword