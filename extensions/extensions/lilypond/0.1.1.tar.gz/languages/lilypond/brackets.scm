("{" @open "}" @close)
(("\"" @open "\"" @close) (#set! rainbow.exclude))
("<" @open ">" @close)
("<<" @open ">>" @close)
("#{" @open "#}" @close)

("(" @open ")" @close)
