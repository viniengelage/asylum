; Instructions (keywords)
(from_instruction
  "FROM" @keyword)

(parameter_instruction
  "PARAMETER" @keyword)

(requires_instruction
  "REQUIRES" @keyword)

(message_instruction
  "MESSAGE" @keyword)

(template_instruction
  "TEMPLATE" @keyword)

(system_instruction
  "SYSTEM" @keyword)

(license_instruction
  "LICENSE" @keyword)

(adapter_instruction
  "ADAPTER" @keyword)


; Arguments
(argument) @variable.parameter

; Values
(number) @number

(quoted_string) @string

(multiline_string) @string

(parameter_value) @string


; Comments
(comment) @comment
