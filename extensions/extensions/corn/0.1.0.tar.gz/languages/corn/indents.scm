(array "]" @end) @indent
(object "}" @end) @indent
(assign_block "}" @end) @indent
