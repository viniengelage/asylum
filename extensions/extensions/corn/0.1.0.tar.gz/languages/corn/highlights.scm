"let" @keyword
"in" @keyword

[
	"{"
	"}"
	"["
	"]"
] @punctuation.bracket

(path_seg) @variable
"." @punctuation.delimiter

"=" @operator

(input) @constant
(comment) @comment

(string) @string
(char) @string
(integer) @number
(float) @float
(boolean) @boolean
(null) @keyword

(ERROR) @error
