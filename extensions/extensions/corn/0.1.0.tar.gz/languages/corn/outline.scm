(pair (path) @name) @item
(assignment (input) @name) @item
