; highlights.scm — Tree-sitter highlight queries for Houdini VEX

; ── Comments ──────────────────────────────────────────────

(comment) @comment

; ── Preprocessor ──────────────────────────────────────────

(preprocessor
  "#" @keyword.directive
  directive: (preprocessor_directive) @keyword.directive)

(preprocessor
  argument: (preprocessor_arg) @string)

; ── Literals ──────────────────────────────────────────────

(number_literal) @number

(string_literal) @string
(string_content) @string
(escape_sequence) @string.escape

; ── Types ─────────────────────────────────────────────────

(primitive_type) @type.builtin
(type_identifier) @type

; ── Keywords ──────────────────────────────────────────────

"function" @keyword.function
"struct" @keyword.type

"if" @keyword.conditional
"else" @keyword.conditional

"for" @keyword.repeat
"foreach" @keyword.repeat
"while" @keyword.repeat
"do" @keyword.repeat

"return" @keyword.return
"break" @keyword
"continue" @keyword

"export" @keyword.modifier
"const" @keyword.modifier

; ── Functions ─────────────────────────────────────────────

(function_declaration
  name: (identifier) @function)

(call_expression
  function: (identifier) @function.call)

(call_expression
  function: (member_expression
    member: (identifier) @function.method.call))

(call_expression
  function: (identifier) @function.builtin
  (#match? @function.builtin "^(Du|Dv|Dw|__uniform_mul|__uniform_premul|abs|abspath|accessframe|acos|addattrib|addattribute|adddetailattrib|addgroup|addpoint|addpointattrib|addprim|addprimattrib|addvariablename|addvertex|addvertexattrib|addvisualizer|agentaddclip|agentchannelcount|agentchannelnames|agentchannelvalue|agentchannelvalues|agentclipcatalog|agentclipchannel|agentclipchannelnames|agentcliplayerblend|agentcliplayersamplelocal|agentcliplayersampleworld|agentcliplength|agentclipnames|agentclipsample|agentclipsamplelocal|agentclipsamplerate|agentclipsampleworld|agentclipstarttime|agentcliptimes|agentcliptransformgroups|agentclipweights|agentcollisionlayer|agentcollisionlayers|agentcurrentlayer|agentcurrentlayers|agentfindclip|agentfindlayer|agentfindtransformgroup|agentlayerbindings|agentlayers|agentlayershapes|agentlocaltransform|agentlocaltransforms|agentmetadata|agentrestlocaltransform|agentrestworldtransform|agentrigchildren|agentrigfind|agentrigfindchannel|agentrigparent|agentsolvefbik|agenttransformcount|agenttransformgroupmember|agenttransformgroupmemberchannel|agenttransformgroups|agenttransformgroupweight|agenttransformnames|agenttransformtolocal|agenttransformtoworld|agentworldtransform|agentworldtransforms|albedo|alphaname|ambient|anoise|append|area|argsort|array|ashikhmin|asin|assert_enabled|assign|atan|atan2|atof|atoi|atten|attrib|attribclass|attribdataid|attribsize|attribtype|attribtypeinfo|avg|binput|blackbody|blinn|blinnBRDF|bouncelabel|bouncemask|bumpmap|bumpmapA|bumpmapB|bumpmapG|bumpmapL|bumpmapR|bumpname|cbrt|ceil|ch|ch2|ch3|ch4|chadd|chattr|chattrnames|chdict|chend|chendf|chendt|chexpr|chexprf|chexprt|chf|chi|chiang|chiang_fur|chid|chindex|chinput|chinputlimits|chname|chnames|chnumchan|chop|choplocal|choplocalt|chopt|chp|chprim_clear|chprim_destroykey|chprim_end|chprim_eval|chprim_insertkey|chprim_keycount|chprim_keytimes|chprim_keyvalues|chprim_length|chprim_setkeyaccel|chprim_setkeyslope|chprim_setkeyvalue|chprim_start|chr|chramp|chrampderiv|chrate|chreadbuf|chremove|chremoveattr|chrename|chresizebuf|chs|chsetattr|chsetlength|chsetrate|chsetstart|chsop|chsraw|chstart|chstartf|chstartt|chu|chv|chwritebuf|cinput|ckspline|clamp|clip|colormap|colorname|combinelocaltransform|computenormal|concat|cone|cos|cosh|cospi|cracktransform|create_cdf|create_pdf|cregioncapturetransform|cregiondeformtransform|cregionoverridetransform|cross|cspline|ctransform|curlgxnoise|curlgxnoise2d|curlnoise|curlnoise2d|curlxnoise|curlxnoise2d|curvearclen|cvex_bsdf|cwnoise|decode|decodeattrib|decodeparm|decodeutf8|degrees|depthmap|depthname|detail|detailattrib|detailattribsize|detailattribtype|detailattribtypeinfo|detailintrinsic|determinant|diag|diagonalizesymmetric|diffuse|diffuseBRDF|dihedral|dimport|distance|distance2|distance_pointline|distance_pointray|distance_pointsegment|dot|dsmpixel|efit|eigenvalues|encode|encodeattrib|encodeparm|encodeutf8|endswith|environment|erf|erf_inv|erfc|error|eulertoquaternion|eval_bsdf|exp|expand_udim|expandedgegroup|expandpointgroup|expandprimgroup|expandvertexgroup|extractlocaltransform|fastshadow|filamentsample|file_stat|filter_remap|filtershadow|filterstep|find|findattribval|findattribvalcount|findlowerboundsorted|findsorted|finput|fit|fit01|fit10|fit11|floor|flownoise|flowpnoise|frac|fresnel|fromNDC|frontface|fuzzify|fuzzy_and|fuzzy_defuzz_centroid|fuzzy_nand|fuzzy_nor|fuzzy_not|fuzzy_nxor|fuzzy_or|fuzzy_xor|geoself|geounwrap|getattrib|getattribute|getbbox|getbbox_center|getbbox_max|getbbox_min|getbbox_size|getblurP|getbounces|getbounds|getcomp|getcomponents|getderiv|getfogname|getglobalraylevel|getgroupid|getlight|getlightid|getlightname|getlights|getlightscope|getlocalcurvature|getmaterial|getmaterialid|getobjectid|getobjectname|getpackedtransform|getphotonlight|getpointbbox|getpointbbox_center|getpointbbox_max|getpointbbox_min|getpointbbox_size|getprimid|getptextureid|getraylevel|getrayweight|getsamplestore|getscope|getsmoothP|getspace|getuvtangents|ggx|gradient|gxnoise|gxnoised|hair|has_udim|hasattrib|hasdetailattrib|haslight|hasmetadata|hasplane|haspointattrib|hasprimattrib|hasvertexattrib|hedge_dstpoint|hedge_dstvertex|hedge_equivcount|hedge_isequiv|hedge_isprimary|hedge_isvalid|hedge_next|hedge_nextequiv|hedge_postdstpoint|hedge_postdstvertex|hedge_presrcpoint|hedge_presrcvertex|hedge_prev|hedge_prim|hedge_primary|hedge_srcpoint|hedge_srcvertex|henyeygreenstein|hex_adjacent|hex_faceindex|hscript_noise|hscript_rand|hscript_snoise|hscript_sturb|hscript_turb|hsvtorgb|iaspect|ichname|ident|idtopoint|idtoprim|iend|iendtime|ihasplane|import|importance_remap|inedgegroup|ingroup|inpointgroup|inprimgroup|insert|instance|integratehoseksky|interpolate|intersect|intersect_all|intersect_lights|inumplanes|invert|invertexgroup|invlerp|iplaneindex|iplanename|iplanesize|irate|irradiance|isalpha|isbound|isconnected|isdigit|isfinite|isfogray|isframes|isinf|islpeactive|isnan|isotropic|israytracing|issamples|isseconds|isshadingRHS|isshadowray|istart|istarttime|isuvrendering|isvalidindex|isvarying|itoa|ixres|iyres|join|json_dumps|json_loads|keys|kspline|len|length|length2|lerp|lightbounces|lightid|lightstate|limit_sample_space|limport|lkspline|log|log10|lookat|lspline|lstrip|luminance|lumname|makebasis|maketransform|makevalidvarname|mask_bsdf|maskname|match|matchvex_blinn|matchvex_specular|mattrib|max|mdensity|medulla_diffuse|medulla_henyeygreenstein|metadata|metaimport|metamarch|metanext|metastart|metaweight|min|minpos|mspace|mwnoise|mx_cellnoise|mx_perlin|mx_voronoi|mx_worley|nametopoint|nametoprim|nbouncetypes|ndcdepth|nearpoint|nearpoints|nedgesgroup|neighbour|neighbourcount|neighbours|newgroup|newsampler|nextsample|ninput|ninputs|noise|noised|norm_1|norm_fro|norm_inf|norm_max|norm_spectral|normal_bsdf|normalize|normalname|npoints|npointsgroup|nprimitives|nprimitivesgroup|nrandom|ntransform|nuniqueval|nvertices|nverticesgroup|objectstate|occlusion|ocean_sample|ocio_activedisplays|ocio_activeviews|ocio_import|ocio_parsecolorspace|ocio_roles|ocio_spaces|ocio_transform|ocio_transformview|ocio_transformviewreverse|onoise|opdigits|opend|opfullpath|opid|opparentbonetransform|opparenttransform|opparmtransform|oppreconstrainttransform|oppreparmtransform|opprerawparmtransform|oppretransform|oprawparmtransform|opstart|optransform|ord|orthographic|osd_facecount|osd_firstpatch|osd_limit|osd_limitsurface|osd_limitsurfacevertex|osd_lookupface|osd_lookuppatch|osd_patchcount|osd_patches|outerproduct|ow_nspace|ow_space|ow_vspace|pack_inttosafefloat|packedtransform|pathtrace|pcclose|pccone|pccone_radius|pcconvex|pcexport|pcfarthest|pcfilter|pcfind|pcfind_radius|pcgenerate|pcimport|pcimportbyidx3|pcimportbyidx4|pcimportbyidxf|pcimportbyidxi|pcimportbyidxp|pcimportbyidxs|pcimportbyidxv|pciterate|pcline|pcline_radius|pcnumfound|pcopen|pcopenlod|pcsampleleaf|pcsegment|pcsegment_radius|pcsize|pcunshaded|pcwrite|perspective|pgfind|phong|phongBRDF|phonglobe|photonmap|pinvert|planeindex|planename|planepointdistance|planesize|planesphereintersect|pluralize|pnoise|point|pointattrib|pointattribsize|pointattribtype|pointattribtypeinfo|pointedge|pointhedge|pointhedgenext|pointlocaltransforms|pointname|pointprims|pointprimuv|pointtransform|pointtransformrigid|pointtransforms|pointtransformsrigid|pointvertex|pointvertices|polardecomp|polyneighbours|pop|pow|predicate_incircle|predicate_insphere|predicate_orient2d|predicate_orient3d|premul|prerotate|prescale|pretranslate|prim|prim_attribute|prim_normal|primarclen|primattrib|primattribsize|primattribtype|primattribtypeinfo|primduv|primfind|primhedge|priminteriorweights|primintrinsic|primpoint|primpoints|primuv|primuvconvert|primvertex|primvertexcount|primvertices|print_once|printf|product|ptexture|ptlined|ptransform|push|pxnoised|py_dumps|py_loads|qconvert|qdistance|qinvert|qmultiply|qrotate|quaternion|quaterniontoeuler|radians|ramp_lookup|ramp_pack|ramp_unpack|rand|random|random_brj|random_fhash|random_ihash|random_poisson|random_shash|random_sobol|rawbumpmap|rawbumpmapA|rawbumpmapB|rawbumpmapG|rawbumpmapL|rawbumpmapR|rawcolormap|rayhittest|rayimport|re_find|re_findall|re_match|re_replace|re_split|reflect|reflectlight|refract|refractlight|relativepath|relbbox|relpath|relpointbbox|removeattrib|removedetailattrib|removegroup|removeindex|removepoint|removepointattrib|removepointgroup|removeprim|removeprimattrib|removeprimgroup|removevalue|removevertex|removevertexattrib|removevertexgroup|renderstate|reorder|replace|replace_match|resample_linear|resize|resolvemissedray|reverse|rgbtohsv|rgbtoxyz|rint|rotate|rotate_x_to|rstrip|sample_bsdf|sample_cauchy|sample_cdf|sample_circle_arc|sample_circle_edge_uniform|sample_circle_ring_uniform|sample_circle_slice|sample_circle_uniform|sample_direction_cone|sample_direction_uniform|sample_discrete|sample_exponential|sample_geometry|sample_hemisphere|sample_hypersphere_cone|sample_hypersphere_uniform|sample_light|sample_lognormal|sample_lognormal_by_median|sample_normal|sample_orientation_cone|sample_orientation_uniform|sample_photon|sample_sphere_cone|sample_sphere_shell_uniform|sample_sphere_uniform|sampledisk|scale|scatter|select|sensor_panorama_create|sensor_panorama_getcolor|sensor_panorama_getcone|sensor_panorama_getdepth|sensor_save|serialize|set|setagentchannelvalue|setagentchannelvalues|setagentclipnames|setagentclips|setagentcliptimes|setagentclipweights|setagentcollisionlayer|setagentcollisionlayers|setagentcurrentlayer|setagentcurrentlayers|setagentlocaltransform|setagentlocaltransforms|setagentworldtransform|setagentworldtransforms|setattrib|setattribtypeinfo|setcomp|setcurrentlight|setdetailattrib|setdetailintrinsic|setedgegroup|setpackedtransform|setpointattrib|setpointgroup|setpointlocaltransforms|setpointtransform|setpointtransforms|setprimattrib|setprimgroup|setprimintrinsic|setprimvertex|setsamplestore|setvertexattrib|setvertexgroup|setvertexpoint|shadow|shadow_light|shadowmap|sheen|shimport|shl|shr|shrz|sign|simport|sin|sinh|sinpi|sleep|slerp|slerpv|slice|slideframe|smooth|smoothrotation|snoise|solid_angle|solveconstraint|solvecubic|solvecurve|solvefbik|solveik|solvephysfbik|solvepoly|solvequadratic|solvetriangleSSS|sort|specular|specularBRDF|spline|spline_cdf|split|split_bsdf|splitpath|sprintf|sqrt|sssapprox|startswith|storelightexport|strip|strlen|sum|surfacedist|svddecomp|switch|swizzle|tan|tanh|tanpi|tet_adjacent|tet_faceindex|teximport|texprintf|texture|texture3d|texture3dBox|titlecase|toNDC|tolower|toupper|tr|trace|translate|translucent|transpose|trunc|tw_nspace|tw_space|tw_vspace|typeid|uniqueval|uniquevals|unpack_intfromsafefloat|unserialize|upush|usd_addattrib|usd_addcollectionexclude|usd_addcollectioninclude|usd_addinversetotransformorder|usd_addorient|usd_addprim|usd_addprimvar|usd_addrelationshiptarget|usd_addrotate|usd_addscale|usd_addschemaattrib|usd_addtotransformorder|usd_addtransform|usd_addtranslate|usd_applyapi|usd_attrib|usd_attribelement|usd_attriblen|usd_attribnames|usd_attribsize|usd_attribtimesamples|usd_attribtypename|usd_bindmaterial|usd_blockattrib|usd_blockprimvar|usd_blockprimvarindices|usd_blockrelationship|usd_boundmaterialpath|usd_childnames|usd_clearmetadata|usd_cleartransformorder|usd_collectioncomputedpaths|usd_collectioncontains|usd_collectionexcludes|usd_collectionexpansionrule|usd_collectionincludes|usd_drawmode|usd_findtransformname|usd_flattenediprimvar|usd_flattenediprimvarelement|usd_flattenedprimvar|usd_flattenedprimvarelement|usd_getbbox|usd_getbbox_center|usd_getbbox_max|usd_getbbox_min|usd_getbbox_size|usd_getbounds|usd_getpointinstancebounds|usd_hasapi|usd_haspayload|usd_iprimvar|usd_iprimvarelement|usd_iprimvarelementsize|usd_iprimvarindices|usd_iprimvarinterpolation|usd_iprimvarlen|usd_iprimvarnames|usd_iprimvarsize|usd_iprimvartimesamples|usd_iprimvartypename|usd_isabstract|usd_isactive|usd_isarray|usd_isarrayiprimvar|usd_isarraymetadata|usd_isarrayprimvar|usd_isattrib|usd_iscollection|usd_iscollectionpath|usd_isindexediprimvar|usd_isindexedprimvar|usd_isinstance|usd_isiprimvar|usd_iskind|usd_ismetadata|usd_ismodel|usd_isprim|usd_isprimvar|usd_isrelationship|usd_isstage|usd_istransformreset|usd_istype|usd_isvisible|usd_kind|usd_localtransform|usd_makeattribpath|usd_makecollectionpath|usd_makepropertypath|usd_makerelationshippath|usd_makevalidprimname|usd_makevalidprimpath|usd_metadata|usd_metadataelement|usd_metadatalen|usd_metadatanames|usd_name|usd_parentpath|usd_pointinstance_getbbox|usd_pointinstance_getbbox_center|usd_pointinstance_getbbox_max|usd_pointinstance_getbbox_min|usd_pointinstance_getbbox_size|usd_pointinstance_relbbox|usd_pointinstancetransform|usd_primvar|usd_primvarattribname|usd_primvarelement|usd_primvarelementsize|usd_primvarindices|usd_primvarinterpolation|usd_primvarlen|usd_primvarnames|usd_primvarsize|usd_primvartimesamples|usd_primvartypename|usd_purpose|usd_relationshipforwardedtargets|usd_relationshipnames|usd_relationshiptargets|usd_relbbox|usd_removerelationshiptarget|usd_setactive|usd_setattrib|usd_setattribelement|usd_setcollectionexcludes|usd_setcollectionexpansionrule|usd_setcollectionincludes|usd_setdrawmode|usd_setkind|usd_setmetadata|usd_setmetadataelement|usd_setprimvar|usd_setprimvarelement|usd_setprimvarelementsize|usd_setprimvarindices|usd_setprimvarinterpolation|usd_setpurpose|usd_setrelationshiptargets|usd_settransformorder|usd_settransformreset|usd_setvariantselection|usd_setvisibility|usd_setvisible|usd_specifier|usd_transformname|usd_transformorder|usd_transformsuffix|usd_transformtype|usd_typename|usd_uniquetransformname|usd_variants|usd_variantselection|usd_variantsets|usd_worldtransform|uvdist|uvintersect|uvsample|uvunwrap|variance|velocityname|vertex|vertexattrib|vertexattribsize|vertexattribtype|vertexattribtypeinfo|vertexcurveparam|vertexhedge|vertexindex|vertexnext|vertexpoint|vertexprev|vertexprim|vertexprimindex|vnoise|volume|volumecubicsample|volumecubicsamplev|volumegradient|volumeindex|volumeindexactive|volumeindexi|volumeindexorigin|volumeindexp|volumeindextopos|volumeindexu|volumeindexv|volumepostoindex|volumeres|volumesample|volumesamplei|volumesamplep|volumesampleu|volumesamplev|volumesmoothsample|volumesmoothsamplev|volumetypeid|volumevoxeldiameter|vtransform|warning|weightarrayblend|weightarrayfromname|weightarraynormalize|weightarraythreshold|windingnumber|windingnumber2d|wireblinn|wirediffuse|wnoise|wo_nspace|wo_space|wo_vspace|writepixel|wt_nspace|wt_space|wt_vspace|xnoise|xnoise|xnoised|xyzdist|xyztorgb)$"))


; ── Structs ───────────────────────────────────────────────

(struct_declaration
  name: (identifier) @type.definition)

(struct_field
  name: (identifier) @variable.special)

; ── Variables & parameters ────────────────────────────────

(variable_declarator
  name: (identifier) @variable)

(parameter_declarator
  name: (identifier) @variable.parameter)

; ── Member access ─────────────────────────────────────────

(member_expression
  member: (identifier) @variable.special)

(member_expression
  object: (identifier) @constant
  (#eq? @constant "this"))

; ── Geometry attributes (VEX-specific) ────────────────────

(attribute_access
  type_hint: (attribute_type_hint) @attribute)

(attribute_access
  "@" @attribute)

(attribute_access
  name: (identifier) @attribute)

; ── Operators ─────────────────────────────────────────────

[
  "="
  "+="
  "-="
  "*="
  "/="
  "%="
  "<<="
  ">>="
  "&="
  "|="
  "^="
] @operator

[
  "+"
  "-"
  "*"
  "/"
  "%"
] @operator

[
  "=="
  "!="
  "<"
  ">"
  "<="
  ">="
] @operator

[
  "&&"
  "||"
  "!"
] @operator

[
  "&"
  "|"
  "^"
  "~"
  "<<"
  ">>"
] @operator

[
  "++"
  "--"
] @operator

"?" @operator
":" @operator

; ── Punctuation ───────────────────────────────────────────

["(" ")"] @punctuation.bracket
["[" "]"] @punctuation.bracket
["{" "}"] @punctuation.bracket

";" @punctuation.delimiter
"," @punctuation.delimiter
"." @punctuation.delimiter
"->" @punctuation.delimiter
