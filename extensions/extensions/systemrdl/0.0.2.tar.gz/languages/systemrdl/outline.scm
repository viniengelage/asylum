(component_named_def
    type: (_) @context
    id: (_) @name
    ) @item

(component_def
    (component_anon_def
        type: (_) @context
        )
    (component_insts
        (component_inst
            id: (_) @name))) @item

(explicit_component_inst
    id: (_) @context
    (component_insts
        (component_inst
            id: (_) @name))
    ) @item
