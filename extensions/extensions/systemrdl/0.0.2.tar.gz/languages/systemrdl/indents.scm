(component_body "}" @end) @indent
(enum_body "}" @end) @indent
(struct_body "}" @end) @indent
(constraint_body "}" @end) @indent
