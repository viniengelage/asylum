(comment) @comment

[(component_type) (component_inst_type)] @keyword

(string_literal) @string

(number) @number

(prop_assignment_lhs) @property

(explicit_encode_assignment "encode" @property)

(enum_def) @enum
(enum_def (id) @type)

(prop_ref (id) @property)

[(unary_operator)
 (binary_operator)
] @operator

[
  ";"
  ":"
] @punctuation.delimiter

[
  "{"
  "}"
  "["
  "]"
] @punctuation.bracket

[
(accesstype_literal)
(onreadtype_literal)
(onwritetype_literal)
(addressingtype_literal)
(precedencetype_literal)
(boolean_literal)
] @constant.builtin

(enumerator_literal) @constant

(component_named_def
    id: (_) @type)

(explicit_component_inst
    id: (_) @type)
