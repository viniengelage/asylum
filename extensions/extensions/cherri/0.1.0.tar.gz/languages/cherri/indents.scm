; Indent for block structures
[
  (block)
  (dictionary)
] @indent

; Indent for control flow bodies
(if_statement consequence: (_) @indent)
(if_statement alternative: (_) @indent)
(for_statement body: (_) @indent)
(repeat_statement body: (_) @indent)
(menu_statement body: (_) @indent)
(item_statement body: (_) @indent)

; Indent function call arguments when multiline
(call arguments: (_) @indent)

; Outdent closing braces
[
  "}"
  ")"
] @outdent
