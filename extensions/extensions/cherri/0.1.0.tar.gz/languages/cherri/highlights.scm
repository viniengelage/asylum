; Comments
(comment) @comment

; Pragma directives
(pragma_directive) @keyword.directive

; Built-in constructs (normal context)
(builtin_keyword) @keyword.builtin
(builtin_constant) @constant.builtin

; Type keywords - GENERAL rule first
(type_keyword) @type.builtin

; Literals
(boolean) @constant.builtin.boolean
(number) @constant.numeric
(string) @string
(single_quoted_string) @string
(string_content) @string
(interpolation) @string.special

; Identifiers
(identifier) @variable

; At-variables - highlighted with special styling
(at_variable) @variable.special

; Function calls
(call function: (identifier) @function.call)
(call function: (builtin_keyword) @function.builtin)
(call function: (type_keyword) @function.builtin)

; Dictionary pairs
(dictionary_pair key: (identifier) @property)
(dictionary_pair key: (string) @property)

; Different assignment types
(variable_assignment name: (at_variable) @variable.special)
(constant_assignment name: (identifier) @variable)
(identifier_assignment name: (identifier) @variable)
(declaration name: (at_variable) @variable.special)

; Control flow variables
(for_statement variable: (identifier) @variable.parameter)
(repeat_statement variable: (identifier) @variable.parameter)

; Control flow keywords
(for_statement "for" @keyword.control)
(for_statement "in" @keyword.control)
(repeat_statement "repeat" @keyword.control)
(if_statement "if" @keyword.control)
(if_statement "else" @keyword.control)
(menu_statement "menu" @keyword)
(item_statement "item" @keyword)
(constant_assignment "const" @keyword)

; Operators
"=" @operator
"+" @operator
"-" @operator
"*" @operator
"/" @operator
"==" @operator
"!=" @operator
"<" @operator
">" @operator
"<=" @operator
">=" @operator

; Punctuation
"(" @punctuation.bracket
")" @punctuation.bracket
"{" @punctuation.bracket
"}" @punctuation.bracket
":" @punctuation.delimiter
"," @punctuation.delimiter

; SPECIFIC CONTEXT OVERRIDES - these come LAST to override general rules
; Highlight type_keyword as builtin keyword when used in pragma context
(pragma value: (type_keyword) @keyword.builtin)
