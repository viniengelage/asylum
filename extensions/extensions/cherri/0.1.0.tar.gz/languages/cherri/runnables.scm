(
    (source_file
        .
        (_) @run
    )
    (#set! tag cherri-open)
)
