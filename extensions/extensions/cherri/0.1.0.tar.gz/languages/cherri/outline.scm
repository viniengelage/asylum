; Pragma definitions for outline
(pragma
  (pragma_directive) @context
  value: (_) @name) @item

; Variable declarations and assignments
(declaration
  name: (at_variable) @name) @item

(variable_assignment
  name: (at_variable) @name) @item

(constant_assignment
  name: (identifier) @name) @item

; Control flow structures
(if_statement
  condition: (_) @context) @item

(for_statement
  variable: (identifier) @name
  iterable: (_) @context) @item

(repeat_statement
  variable: (identifier)? @name
  count: (_)? @context) @item

(menu_statement
  title: (_)? @name) @item

(item_statement
  title: (_) @name) @item

; Function calls at statement level
(call
  function: (_) @name) @item
