(class
  body: (_) @class.inside) @class.around

(trait
  body: (_) @class.inside) @class.around

(method
  body: (_) @function.inside) @function.around

(reopen_class
  body: (_) @class.inside) @class.around

(implement_trait
  body: (_) @class.inside) @class.around

(external_function
  body: (_) @function.inside) @function.around

(closure
  body: (_) @function.inside) @function.around

(line_comment) @comment.inside

(line_comment)+ @comment.around
