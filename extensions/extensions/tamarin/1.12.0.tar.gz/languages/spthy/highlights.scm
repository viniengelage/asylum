[
  "rule"
  "let"
  "in"
  "theory"
  "begin"
  "end"
  "functions"
  "builtins"
  "restriction"
  "equations"
  "lemma"
  "tactic"
  "presort"
  "prio"
  "deprio"
] @keyword

(multi_comment) @comment
(single_comment) @comment
(formal_comment) @comment

(theory (ident) @type)

(built_in) @type
(natural) @number

(function_untyped (ident) @function)
(function_typed (ident) @function)

(pub_var (ident) @variable)
(fresh_var (ident) @variable)
(msg_var_or_nullary_fun (ident) @variable)
(nat_var (ident) @variable)
(temporal_var ["#" (ident)] @constant.numeric.integer)
(quantified_formula ["All" "Ex" "∀" "∃"] @keyword)
(negation ["not" "¬"] @keyword)

(simple_rule (ident) @type)
(rule_attr) @variable
(rule_attr (rule_attr_color (hexcolor) @constant.numeric.integer))

(nary_app (ident) @function)
(nary_app ["(" ")"] @punctuation.bracket)
(arguments [","] @punctuation.delimiter)

(linear_fact (ident) @function)
(persistent_fact (ident) @function)

(restriction (ident) @type)

(lemma (ident) @type)
(lemma_attr) @variable
(lemma_attr (ident) @type) @variable
(oracle_proof_method_ranking ["\""] @string)

(trace_quantifier) @keyword

(solved) @keyword
(mirrored) @keyword
(by_method ["by"] @keyword)
(cases ["next" "qed"] @keyword)
(case ["case"] @keyword (ident) @type)
(proof_method ["sorry" "simplify" "solve" "contradiction" "induction" "rule-equivalence" "backward-search" "ATTACK"] @keyword)
(step ["step"] @keyword)

(pub_name) @string
(fresh_name) @string
(param) @string


[","] @punctuation.delimiter
["(" ")" "[" "]" "<" ">"] @punctuation.bracket
