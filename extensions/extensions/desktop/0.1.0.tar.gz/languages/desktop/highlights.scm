(comment) @comment

(group_name) @constant

(escape_sequence) @string.escape

; keys

(entry
  key: (identifier) @property)

(field_code) @string.special.symbol

[
  (language)
  (country)
  (encoding)
  (modifier)
] @string.special

; values

(string) @string

((entry
  key: (identifier) @property
  value: (string) @number)
  (#eq? @property "Version"))

((entry
  key: (identifier) @property
  value: (string) @link_uri)
  (#eq? @property "URL"))

[
  (true)
  (false)
] @boolean

; operators & punctuation

"=" @operator

[
  ";"
  "_"
  "."
  "@"
] @punctuation.delimiter

[
  "["
  "]"
] @punctuation.bracket
