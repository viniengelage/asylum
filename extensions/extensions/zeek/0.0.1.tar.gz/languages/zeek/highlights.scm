;; Language features
;; -----------------

(id) @variable

(event (id) @function)
(hook (id) @function)
(func (id) @function)
(expr (id) @function "(")
(expr (expr "$" (id) @function) "(")
(type) @type
(type (id) @type)
(attr) @attribute

;; Literals
;; --------

(minor_comment) @comment
(zeekygen_head_comment) @property
(zeekygen_prev_comment) @property
(zeekygen_next_comment) @property
(string) @string
(constant) @constant

;; Tokens
;; ------
[
 ":"
 ";"
 "$"
] @punctuation.delimiter

[
 "("
 ")"
 "["
 "]"
 "{"
 "}"
] @punctuation.bracket

[
 "|"
 "++"
 "--"
 "!"
 "~"
 "-"
 "+"
 "as"
 "is"
 "*"
 "/"
 "%"
 "+"
 "-"
 "<"
 "<="
 ">"
 ">="
 "=="
 "!="
 "&"
 "^"
 "|"
 "&&"
 "||"
 "?"
 "in"
 "="
 "-="
 "+="
] @operator

[
 "add"
 "assert"
 "break"
 "case"
 "const"
 "copy"
 "default"
 "delete"
 "enum"
 "event"
 "export"
 "fallthrough"
 "for"
 "function"
 "global"
 "hook"
 "if"
 "local"
 "module"
 "next"
 "option"
 "print"
 "record"
 "redef"
 "return"
 "schedule"
 "switch"
 "timeout"
 "type"
 "when"
 "while"
 "@deprecated"
 "@load"
 "@load-sigs"
 "@load-plugin"
 "@unload"
 "@prefixes"
 "@if"
 "@ifdef"
 "@ifndef"
 "@endif"
 "@else"
 "@pragma"
 "@DIR"
 "@FILENAME"
 ] @keyword
