; taken from https://github.com/potassco/tree-sitter-clingo/blob/main/queries/injections.scm

((script
  language: (identifier) @injection.language
  code: (code) @injection.content)
 (#set! injection.combined))
