; taken from https://github.com/potassco/tree-sitter-clingo/blob/main/queries/textobjects.scm


(statement) @function.outer
