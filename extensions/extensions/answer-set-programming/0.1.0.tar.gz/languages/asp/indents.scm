; Indent body after :- in rules
(rule
  ":-" @indent.begin
  body: (_) @indent) @indent.scope

(weak_constraint
  ":~" @indent.align
  body: (_) @indent)

(integrity_constraint
  ":-" @indent.align
  body: (_) @indent)

; End indentation at the period
[
  (rule ".")
] @indent.end
