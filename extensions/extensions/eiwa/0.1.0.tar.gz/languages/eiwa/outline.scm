(class_declaration
  (modifiers)? @context
  (type_identifier) @name) @item

(type_declaration
  "type" @context
  (type_identifier)? @name) @item

(contract_declaration
  "contract" @context
  (type_identifier) @name) @item

(skill_declaration
  "skill" @context
  (type_identifier) @name) @item

(object_declaration
  "object" @context
  (type_identifier)? @name) @item

(enum_declaration
  "enum" @context
  (type_identifier) @name) @item

(lib_declaration
  "lib" @context
  (type_identifier) @name) @item

(test_declaration
  "test" @context
  (string_literal) @name) @item

(enum_entry
  (simple_identifier) @name) @item

(function_declaration
  "fun" @context
  (simple_identifier) @name) @item

(property_declaration
  (binding_pattern_kind) @context
  (variable_declaration
    (simple_identifier) @name)) @item

(companion_object
  "companion" @context
  "object" @context
  (type_identifier)? @name) @item

(secondary_constructor
  "constructor" @name) @item

(anonymous_initializer
  "init" @name) @item
