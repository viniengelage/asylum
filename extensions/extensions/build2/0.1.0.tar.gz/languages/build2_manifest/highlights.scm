(comment) @comment @spell
(version) @number
(number) @number

(dependency
  name: (identifier) @property)

(url) @string.special.url
(email) @string.special.url

(string) @string

["depends"] @keyword.builtin

(pair
  key: (identifier) @keyword.builtin)

":" @punctuation.delimiter

"*" @character.special

[
 "^"
 "=="
 "!="
 ">="
 "<="
 ">"
 "<"
] @operator
