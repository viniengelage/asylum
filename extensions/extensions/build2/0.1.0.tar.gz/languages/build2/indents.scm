(scope "{" @indent)
(scope "}" @outdent)

(for_statement
  body: "{" @indent)

(for_statement
  body: "}" @outdent)

(while_statement
  body: "{" @indent)

(while_statement
  body: "}" @outdent)

(open_tailing_scope) @indent

(configuration "}" @outdent)

(switch_statement "{" @indent)
(switch_statement "}" @outdent)
