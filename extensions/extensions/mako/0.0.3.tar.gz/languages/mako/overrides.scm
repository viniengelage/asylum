[
  (comment)
  (doc)
] @comment.inclusive

(string) @string
