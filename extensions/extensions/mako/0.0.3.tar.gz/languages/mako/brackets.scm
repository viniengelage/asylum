(("${" @open
  "}" @close)
  (#set! rainbow.exclude))

(("<%" @open
  "%>" @close)
  (#set! rainbow.exclude))

(("<%!" @open
  "%>" @close)
  (#set! rainbow.exclude))

(("<%include" @open
  ["/>" "</%include>"] @close)
  (#set! rainbow.exclude))

(("<%inherit" @open
  ["/>" "</%inherit>"] @close)
  (#set! rainbow.exclude))

(("<%namespace" @open
  ["/>" "</%namespace>"] @close)
  (#set! rainbow.exclude))

(("<%text" @open
  ["/>" "</%text>"] @close)
  (#set! rainbow.exclude))

(("<%doc" @open
  ["/>" "</%doc>"] @close)
  (#set! rainbow.exclude))

(("<%page" @open
  ["/>" "</%page>"] @close)
  (#set! rainbow.exclude))

(("<%block" @open
  ["/>" "</%block>"] @close)
  (#set! rainbow.exclude))

(("<%def" @open
  ["/>" "</%def>"] @close)
  (#set! rainbow.exclude))

(("<%call" @open
  ["/>" "</%call>"] @close)
  (#set! rainbow.exclude))

(("\"" @open
  "\"" @close)
  (#set! rainbow.exclude))
