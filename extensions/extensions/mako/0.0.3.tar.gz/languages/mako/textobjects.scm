[
  (def_block)
  (general_block)
  (call_block)
] @function.around
