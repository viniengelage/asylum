(general_block
  "</%block>" @end) @indent

(def_block
  "</%def>" @end) @indent

(call_block
  "</%call>" @end) @indent

(text_block
  "</%text>" @end) @indent

(doc_block
  "</%doc>" @end) @indent

(namespace_block
  "</%namespace>" @end) @indent
