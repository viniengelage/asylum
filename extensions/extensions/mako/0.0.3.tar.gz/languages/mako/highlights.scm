; Mako template syntax highlighting for Zed.
; Adapted from sbaldasty/tree-sitter-mako's Tree-sitter queries.

; Comments
(comment) @comment
(doc) @comment

; Identifiers and attributes
(identifier) @variable
(qualified_identifier) @property @variable

; Strings
(string) @string

; Template delimiters and directives
[
  "<%"
  "%>"
  "<%!"
  "<%include"
  "<%inherit"
  "<%namespace"
  "<%text"
  "<%doc"
  "<%page"
  "<%block"
  "<%def"
  "<%call"
  "</%include>"
  "</%inherit>"
  "</%namespace>"
  "</%text>"
  "</%doc>"
  "</%page>"
  "</%block>"
  "</%def>"
  "</%call>"
  "/>"
] @keyword

">" @punctuation.bracket

; Python control structure terminators
[
  "endif"
  "endfor"
] @keyword

; Expression delimiters
[
  "${"
  "}"
] @punctuation.bracket

; User-defined tags, e.g. <%foo:bar>
(user_tag
  (identifier) @tag
  ":" @punctuation.delimiter
  (identifier) @tag)

(user_block
  "</%" @keyword
  (user_tag
    (identifier) @tag
    ":" @punctuation.delimiter
    (identifier) @tag)
  ">" @punctuation.bracket)

; Attribute assignments
(attribute
  (identifier) @attribute
  "=" @operator)

; Newline filters and escaped percent lines
(newline_filter) @punctuation.special
(escaped_line_percent) @string.escape

; Expression filters, e.g. ${value | h}
(python_expression_filter
  (qualified_identifier) @function)

; Punctuation
[
  "="
  ","
  "|"
  "."
  ":"
] @punctuation.delimiter

; Embedded content is highlighted by injections.scm.
(injected_html) @embedded
(injected_python_block) @embedded
(injected_python_expression) @embedded
(injected_python_line) @embedded
(text) @text.literal
