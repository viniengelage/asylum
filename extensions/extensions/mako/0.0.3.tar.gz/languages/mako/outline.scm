((def_block
  (attribute
    (identifier) @_attribute
    (string) @name)) @item
  (#eq? @_attribute "name"))

((general_block
  (attribute
    (identifier) @_attribute
    (string) @name)) @item
  (#eq? @_attribute "name"))

((call_block
  (attribute
    (identifier) @_attribute
    (string) @name)) @item
  (#eq? @_attribute "expr"))
