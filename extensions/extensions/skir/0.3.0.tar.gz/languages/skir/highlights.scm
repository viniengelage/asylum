; Highlights for the Skir schema language
; Node names verified against tree-sitter-skir/src/node-types.json

; Keywords
[
  "struct"
  "enum"
  "const"
  "method"
  "import"
  "from"
  "as"
  "removed"
  "null"
] @keyword

; Boolean literals
(boolean) @boolean

; Primitive types
(primitive_type) @type.builtin

; Type references (named types)
(type_reference) @type

; Struct definition names
(struct_definition name: (identifier) @type.definition)

; Enum definition names
(enum_definition name: (identifier) @type.definition)

; Field and variant names (field_definition covers both struct fields and enum variants)
(field_definition name: (identifier) @variable.member)

; Object entry keys (in object_value and partial_object_value literals)
(object_entry key: (identifier) @variable.member)

; Constant names
(constant_definition name: (identifier) @constant)

; Method names
(method_definition name: (identifier) @function)

; Namespace alias in star imports
(star_import alias: (identifier) @namespace)

; Named import identifiers
(named_import (identifier) @type)

; Import paths
(named_import path: (string) @string.special)
(star_import path: (string) @string.special)

; All other strings
(string) @string

; Numbers
(number) @number
(integer) @number

; Stable record identifiers e.g. struct Point(12345)
(stable_id (integer) @number)

; Comments
(comment) @comment
(doc_comment) @comment.doc

; Brackets
[
  "{"
  "}"
  "["
  "]"
  "("
  ")"
  "{|"
  "|}"
] @punctuation.bracket

; Punctuation / operators
[
  ";"
  ","
  ":"
  "="
  "|"
  "?"
  "."
  ".."
  "*"
] @punctuation.delimiter
