; Auto-indentation for Skir
; Opening tokens trigger indent, closing tokens trigger dedent

["{" "{|" "[" "("] @indent
["}" "|}" "]" ")"] @outdent
