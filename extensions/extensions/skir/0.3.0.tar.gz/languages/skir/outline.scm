; Top-level definitions appear in the code outline panel

(struct_definition
  name: (identifier) @name) @item

(enum_definition
  name: (identifier) @name) @item

(constant_definition
  name: (identifier) @name) @item

(method_definition
  name: (identifier) @name) @item

; Nested struct inside struct — show parent as context
(struct_definition
  name: (identifier) @context
  (struct_definition
    name: (identifier) @name) @item)

; Nested struct inside enum
(enum_definition
  name: (identifier) @context
  (struct_definition
    name: (identifier) @name) @item)

; Nested enum inside enum
(enum_definition
  name: (identifier) @context
  (enum_definition
    name: (identifier) @name) @item)
