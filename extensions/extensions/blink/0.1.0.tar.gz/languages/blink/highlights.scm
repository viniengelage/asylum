["type" "option" "event" "function" "enum" "map" "set" "struct" "import" "scope" "as"] @keyword

(primitive_type) @type.builtin

(type_declaration     name: (identifier) @type)
(event_declaration    name: (identifier) @type)
(function_declaration name: (identifier) @type)
(enum_declaration     name: (identifier) @type)
(map_declaration      name: (identifier) @type)
(set_declaration      name: (identifier) @type)
(struct_declaration   name: (identifier) @type)
(scope_declaration    name: (identifier) @type)
(import_declaration   alias: (identifier) @type)

(enum_variant name: (identifier) @variant)

(field_pair   key:  (identifier) @property)
(struct_field name: (identifier) @property)
(option_declaration key:   (identifier) @property)
(option_declaration value: (identifier) @constant)

(type_reference (identifier) @type)

(string)  @string
(number)  @number
(boolean) @boolean
(comment) @comment

["=" ":" "?" ".."] @operator
["{" "}" "[" "]" "(" ")"] @punctuation.bracket
"," @punctuation.delimiter
