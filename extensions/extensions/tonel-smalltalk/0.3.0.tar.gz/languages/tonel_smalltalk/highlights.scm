; Tonel definition keywords
["Class" "Trait" "Extension" "Package"] @keyword

; class-side keyword in method reference
(method_reference "class" @keyword)

; Method reference
(method_reference class_name: (identifier) @type)
(method_reference ">>" @operator)

; Class / global names in method bodies (and elsewhere): leading uppercase, Pharo style.
; Does not match unary/binary selectors (those use unary_identifier / operators).
((identifier) @type
  (#match? @type "^[A-Z]"))

; Selectors
(unary_selector (unary_identifier) @function.method)
(binary_selector (binary_operator) @operator)
(method_reference (keyword) @function.method)

; STON keys (metadata properties)
(ston_key (ston_symbol) @property)
(ston_key (string) @property)

; STON values
(ston_symbol) @string.special
(ston_list) @punctuation.bracket

; Smalltalk literals
(string) @string
(symbol) @string.special
(number) @number
(character) @character
(class_comment) @comment
(comment) @comment

; Pseudo-variables — self/super use @variable.special like TypeScript/JavaScript
; (this/super); fallback left captures if the theme lacks @variable.special
(self) @variable.builtin @variable.special
(super) @variable.builtin @variable.special
[(true) (false)] @boolean
(nil) @variable.builtin @constant.builtin
(thisContext) @variable.builtin @variable.special

; Return operator
"^" @operator

; Cascade
";" @punctuation.delimiter

; Statement separator
"." @punctuation.delimiter

; Blocks and collections
(method_definition "[" @punctuation.bracket "]" @punctuation.bracket)
(ston_list "[" @punctuation.bracket "]" @punctuation.bracket)
(block "[" @punctuation.special "]" @punctuation.special)
["(" ")" "{" "}"] @punctuation.bracket

; Pragma
["<" ">"] @punctuation.bracket
(pragma_unary_selector (unary_identifier) @attribute)
(pragma_keyword_selector (keyword) @attribute)

; Temporaries delimiters
(temporaries "|" @punctuation.delimiter)

; Assignment operator
":=" @operator

; Binary operators in expressions
(binary_message (binary_operator) @operator)
(cascaded_binary_message (binary_operator) @operator)
