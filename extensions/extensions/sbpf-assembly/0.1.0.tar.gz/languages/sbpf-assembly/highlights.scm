[
  (line_comment)
  (block_comment)
] @comment

(label
  name: (symbol) @label)

(directive
  name: (directive_name) @keyword.directive)

(instruction
  opcode: (opcode) @function.builtin)

(register) @variable.special

(number) @number

(memory_operand) @string.special

(memory_operand
  base: (register) @variable.special)

(memory_operand
  offset: (number) @number)

(memory_operand
  offset: (symbol) @constant)

(operand (symbol) @constant)

(string) @string
